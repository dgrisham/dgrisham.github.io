import java.util.Scanner;
import java.io.File;
// import java.io.*;

public class CheckedAndUnchecked {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		doSomething();
	}
	
	public static void doSomething()// throws FileNotFoundException
	{
		int[] nums = new int[10];
		// ArrayIndexOutOfBounds is unchecked, compiler won't complain
		// Exception occurs at run-time
		nums[10] = 5;
		// Try to uncomment the following line.  IOExceptions are checked
		// - the compiler makes you handle them
		// Add a try/catch block or throws clause.  It compiles. 
		// But the error still occurs at run-time
		//Scanner scan = new Scanner(new File("something.txt"));
	}

}
