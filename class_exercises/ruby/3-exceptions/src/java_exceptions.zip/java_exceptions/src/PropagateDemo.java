import java.util.Scanner;

public class PropagateDemo {

	/**
	 * @param args
	*/
	public static void main(String[] args) {
		doExample();
	}
	
	public static void doExample()
	{
		try
		{
			getInput();
		} catch(BadDataException e)
		{
			System.out.println("doExample caught BadDataException");
			System.out.println(e.getCause());
		}
	}
	
	public static void getInput() throws BadDataException
	{
		System.out.println("Enter value from 1 - 10: ");
		Scanner scan = new Scanner(System.in);
		int num = scan.nextInt();
		if (num < 1 || num > 10)
			throw new BadDataException("You can't follow instructions!");		
	}
}
