import java.io.*;
import java.util.*;

public class FinallyDemo2 {

	public void doFileWrite()
	{
		try 
		{
			FileWriter writer = new FileWriter("myfile.txt");
			{
				try 
				{
					writer.write("Hello World!");
					System.out.print("Enter 1 to continue, 2 to quit");
					Scanner scan = new Scanner(System.in);
					int done = scan.nextInt();
					if (done == 2)
						return;
					System.out.println("After checking done");		
				}
				finally 
				{
					writer.close();
				}
			}
		}catch (IOException e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	public static void main(String[] args) 
	{
		FinallyDemo2 fd = new FinallyDemo2();
		fd.doFileWrite();

	}

}
