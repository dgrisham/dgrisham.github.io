import java.util.logging.*;
import java.io.IOException;

public class BadDataException extends Exception {
	private static Logger logger = Logger.getLogger("MyLog");
	
	public BadDataException() {
	}

	public BadDataException(String message) {
		super(message);
		FileHandler fh;

	    try {

	      // This block configure the logger with handler and formatter
	      fh = new FileHandler("MyLogFile.log", true);
	      logger.addHandler(fh);
	      logger.setLevel(Level.ALL);
	      SimpleFormatter formatter = new SimpleFormatter();
	      fh.setFormatter(formatter);

		  logger.log(Level.WARNING, message);

	    } catch (SecurityException e) {
	      e.printStackTrace();
	    } catch (IOException e) {
	      e.printStackTrace();
	    }
	  

	}

}
