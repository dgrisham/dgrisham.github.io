import java.io.*;
import java.util.*;

public class FinallyDemo {
	public void doFileWrite() throws IOException
	{
		FileWriter writer = null;
		try
		{
			writer = new FileWriter("myfile.txt");
			writer.write("Hello World!");
			System.out.print("Enter 1 to continue, 2 to quit");
			Scanner scan = new Scanner(System.in);
			int done = scan.nextInt();
			if (done == 2)
				return;
			System.out.println("After checking done");
		} finally
		{
			System.out.println("in finally");
			writer.close();
		}
		
	}
	
	public static void main(String[] args) throws IOException
	{
		FinallyDemo fd = new FinallyDemo();
		fd.doFileWrite();
	}

}
