require_relative "RubyModules.rb"
text = Base64.encode("something")