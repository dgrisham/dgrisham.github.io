=begin
	Demo: Open class structure
	Corresponds to: RubyModules.pptx
=end

class Cat 
	#attr_accessor :name, :age
	def initialize(name, age)
		@name, @age = name, age
	end
end

