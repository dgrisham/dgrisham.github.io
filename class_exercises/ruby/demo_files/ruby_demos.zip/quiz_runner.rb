require './quiz.rb'
Quiz.instance.run_quiz
