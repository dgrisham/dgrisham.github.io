puts (1/2) 
require "mathn"
puts (1/2) 