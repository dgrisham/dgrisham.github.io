require_relative 'quiz.rb'
Quiz.instance.run_quiz
