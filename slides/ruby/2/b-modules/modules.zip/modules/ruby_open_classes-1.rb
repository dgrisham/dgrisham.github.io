=begin
    Demo: Open class structure
=end

class Pikachu
  attr_accessor :name, :level
  def initialize(name, level)
    @name, @level = name, level
  end
end

# See ruby_open_classes-2.rb for next part
